package AssitedProject2;

public class ThreadsCreation extends Thread{
	public void run()
 	{
  		System.out.println(" Thread started running..");
}
 	public static void main( String args[] )
 	{
        ThreadsCreation mt = new ThreadsCreation();
  		mt.start();
 	}


}
