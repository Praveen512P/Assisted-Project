package AssitedProject2;

public class throwKeyword {
	
        public static void main(String[] args)
        {

            int a=45,b=0,res;

            try
            {
                if(b==0)        
                    throw(new ArithmeticException("Can't divide by zero."));
                else
                {
                    res = a / b;
                    System.out.print("The result is : " + res);
                }
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("Error : " + Ex.getMessage());
            }

            System.out.print("End of program.");
        }


}
