package assistedProject;

public class array {
	public static void main(String[] args) 
	{

		int a[]= {10,20,30,40,50,60};
		for(int i=0;i<6;i++) 
		{
		System.out.println("Elements of array a: "+a[i]);
		}


		int[][] b = {
		            {2, 4, 6, 8}, 
		            {4, 8, 12} 
		            };
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
	}
}
