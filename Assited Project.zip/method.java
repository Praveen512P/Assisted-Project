package assistedProject;

public class method 
{
	public int multipynumbers(int a,int b) {
		int z=a*b;
		return z;
	}

	public static void main(String[] args) {

		method b=new method();
		int ans= b.multipynumbers(9,2);
		System.out.println("Multipilcation is :"+ans);
		}

}
